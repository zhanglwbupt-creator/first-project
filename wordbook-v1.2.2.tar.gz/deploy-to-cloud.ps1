# 一键部署到云主机脚本
# 用法: .\deploy-to-cloud.ps1 [版本号]
# 示例: .\deploy-to-cloud.ps1 1.2.2

param(
    [Parameter(Mandatory=$true)]
    [string]$Version
)

# ==================== 配置区 ====================
$ServerIP = "82.156.202.245"
$ServerPort = "2222"
$ServerUser = "newuser"
$ProjectName = "wordbook"
$RemotePath = "/home/$ServerUser/$ProjectName"
$ZipName = "$ProjectName-v$Version.zip"
$BackupName = "$ProjectName-backup-$(Get-Date -Format 'yyyyMMdd_HHmmss').zip"
# =================================================

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  部署 V$Version 到云主机" -ForegroundColor Cyan
Write-Host "  服务器: $ServerIP" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# 1. 检查打包文件是否存在
Write-Host "`n[1/6] 检查打包文件..." -ForegroundColor Yellow
if (-not (Test-Path $ZipName)) {
    Write-Host "❌ 找不到 $ZipName" -ForegroundColor Red
    Write-Host "请先运行: .\release.ps1 $Version" -ForegroundColor Yellow
    exit 1
}
Write-Host "✅ 找到 $ZipName" -ForegroundColor Green

# 2. 上传到服务器
Write-Host "`n[2/6] 上传到服务器..." -ForegroundColor Yellow
Write-Host "  正在上传 $ZipName 到 $ServerUser@$ServerIP..." -ForegroundColor Gray

$uploadCmd = "scp -P $ServerPort `"$ZipName`" ${ServerUser}@${ServerIP}:~/"
Write-Host "  执行: $uploadCmd" -ForegroundColor Gray
Invoke-Expression $uploadCmd

if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ 上传失败" -ForegroundColor Red
    exit 1
}
Write-Host "✅ 上传完成" -ForegroundColor Green

# 3. SSH执行部署命令
Write-Host "`n[3/6] 备份现有版本..." -ForegroundColor Yellow
$backupCmd = "ssh -p $ServerPort ${ServerUser}@${ServerIP} `"cd $RemotePath && if [ -d 'backend' ]; then zip -r ~/$BackupName . -x 'node_modules/*' 'dist/*'; echo '✅ 备份完成: $BackupName'; else echo '⚠️ 首次部署，跳过备份'; fi`""
Write-Host "  执行备份..." -ForegroundColor Gray
Invoke-Expression $backupCmd

# 4. 解压并部署
Write-Host "`n[4/6] 解压并部署..." -ForegroundColor Yellow
$deployCmds = @"
ssh -p $ServerPort ${ServerUser}@${ServerIP} @"
cd $RemotePath
echo '📦 解压新版本...'
unzip -o ~/$ZipName -d .

echo '🔧 安装后端依赖...'
cd backend
npm install --production

echo '📦 构建前端...'
cd ..
npm install
npm run build

echo '💾 保留数据库...'
if [ -f '../data/wordbook.db' ]; then
    cp ../data/wordbook.db backend/data/ 2>/dev/null || true
fi

echo '🚀 重启服务...'
pm2 restart ${ProjectName}-backend || pm2 start backend/server.js --name ${ProjectName}-backend

echo '✅ 部署完成!'
pm2 status
"@
"@

Write-Host "  执行部署命令..." -ForegroundColor Gray
Invoke-Expression $deployCmds

# 5. 验证服务
Write-Host "`n[5/6] 验证服务状态..." -ForegroundColor Yellow
Start-Sleep -Seconds 3

$checkCmd = "ssh -p $ServerPort ${ServerUser}@${ServerIP} `"pm2 list && echo '---' && curl -s http://localhost:5000/api/health || echo '后端未响应'`""
Invoke-Expression $checkCmd

# 6. 清理
Write-Host "`n[6/6] 清理临时文件..." -ForegroundColor Yellow
$cleanCmd = "ssh -p $ServerPort ${ServerUser}@${ServerIP} `"rm -f ~/$ZipName`""
Invoke-Expression $cleanCmd

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  🎉 部署完成！" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "`n访问地址:" -ForegroundColor Yellow
Write-Host "  前端: http://$ServerIP/" -ForegroundColor White
Write-Host "  后端: http://$ServerIP:5000/" -ForegroundColor White
Write-Host "  PM2管理: ssh -p $ServerPort ${ServerUser}@${ServerIP}" -ForegroundColor White
Write-Host "`n常用命令:" -ForegroundColor Yellow
Write-Host "  查看日志: pm2 logs ${ProjectName}-backend" -ForegroundColor Gray
Write-Host "  重启服务: pm2 restart ${ProjectName}-backend" -ForegroundColor Gray
Write-Host "  停止服务: pm2 stop ${ProjectName}-backend" -ForegroundColor Gray
Write-Host "========================================" -ForegroundColor Cyan
